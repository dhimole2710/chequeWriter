import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';
import { AmountToWords } from './amount.to.words.pipe';
import { FormsModule } from '@angular/forms';

describe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        FormsModule
      ],
      declarations: [
        AppComponent,
        AmountToWords
      ],
    }).compileComponents();
  
    
  }));
  beforeEach(() => {
    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

  describe('validateAmount', () => {
    it('Should check for validateAmount for positive scenario', () => {
      component.amount = '67.99';
      component.validateAmount(component.amount);
      expect(component.validRE).toBe(true);
    });
    it('Should check for validateAmount for negative scenario', () => {
      component.amount = '67.9987777';
      component.validateAmount(component.amount);
      expect(component.validRE).toBe(false);

    });
  });
  describe('decimalView', () => {
    it('Should check for float', () => {
      component.amount = '67.99';
      component.decimalView(component.amount);
      expect(component.amount).toEqual('67.99');
    });
    it('Should check for integer', () => {
      component.amount = '32';
      component.decimalView(component.amount);
      expect(component.amount).toContain('.00');
    });
  });

});
