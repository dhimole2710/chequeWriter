import {AmountToWords } from './amount.to.words.pipe';
import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
describe('AmountToWords', () => {
    let pipe : AmountToWords;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        FormsModule
      ],
      declarations: [
        AppComponent,
        AmountToWords
      ],
    }).compileComponents();
  }));
    beforeEach(() => {
        pipe= new AmountToWords();
    });

    it('should create one instance of pipe', () => {
        expect(pipe).toBeTruthy();
    });
    describe('transform', () => {
        it('output for integer', () => {
            let string = '95.00';
            expect(pipe.transform(string)).toBe('Ninety five dollars');
        });
        it('output for integer', () => {
            let string = '69';
            expect(pipe.transform(string)).toBe('Sixty nine dollars');
        });
        it('output for invalid amount', () => {
            let string = '9999999999999999';
            expect(pipe.transform(string)).toBe(false);
        });
        it('output for float amount', () => {
            let string = '10985.25';
            expect(pipe.transform(string)).toBe('Ten thousand nine hundred eighty five dollars and 25/100');
        });
        it('output for float amount', () => {
            let string = '125.75';
            expect(pipe.transform(string)).toBe('One hundred twenty five dollars and 75/100');
        });
         it('output for 0', () => {
            let string = '0';
            expect(pipe.transform(string)).toBe('');
        });
        it('output for max input', () => {
            let string = '566786585589433';
            expect(pipe.transform(string)).toBe('Five hundred sixty six trillion seven hundred eighty six billion five hundred eighty five million five hundred eighty nine thousand four hundred thirty three dollars');
        });
        
    });
}); 

