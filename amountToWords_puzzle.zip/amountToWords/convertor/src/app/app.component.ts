import { Component,OnInit } from '@angular/core';
import { AmountToWords } from './amount.to.words.pipe';
import { TestBed, async } from '@angular/core/testing';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  public validRE: boolean = true;
  amount: string;
  isNumber: boolean = false;
  headerText: string = 'Cheque Writer';
  validationMsg: string ='You have given wrong input';
  amountText:string ='Enter the Amount';
  public ngOnInit() {
   
   }
  validateAmount(amount) {
    var amountToTest= String(amount)
    var regex = /^[0-9]\d{0,14}(\.\d{1,2})?%?$/g
    this.validRE =regex.test(amountToTest);
  }
  decimalView(amount){
  var amounttemp= parseFloat(amount);
    var contains_dot = amount.indexOf(".");
      if(contains_dot>-1)
      {
        this.amount = amounttemp.toLocaleString('en-IN');
      }
      else{
        this.amount = amounttemp.toLocaleString('en-IN') + '.00';
      }
      
  }
  
}

